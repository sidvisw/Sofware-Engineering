from unittest import mock
from my_package.model import InstanceSegmentationModel